/** @type {import('next').NextConfig} */
const nextConfig = {
  images: {
    domains: ['api.placeholder.com', 'via.placeholder.com'],
  },
}

module.exports = nextConfig